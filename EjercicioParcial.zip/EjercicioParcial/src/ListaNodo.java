
public class ListaNodo {

    int valor;
    ListaNodo siguiente;
    
    public ListaNodo(int valor) {
        this.valor = valor;
        this.siguiente = null;
    }
}
