
package edu.jdc.mvc.view;

import edu.jdc.mvc.control.Control;


public class View {
    private Control objController;
    private String mensaje;
    public View(){
      objController=new Control();   
    }
    public void recibirDatos(String mensaje){
        
    }
 
}
