package edu.jdc.mvc;

import edu.jdc.mvc.control.Control;

public class runner {

    public static void main(String[] args) {

        Control objController = new Control();
        objController.init();
    }

}
