package edu.jdc.runner;

import edu.jdc.controlador.Controlador;



public class Runner {

    public static void main(String[] args) {
Controlador objController=new Controlador();
objController.Menu();
    }

}
