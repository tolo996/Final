
package edu.jdc.control;

import edu.jdc.modelo.juegoModel;


public class Control {
private juegoModel juegoModell;

    public Control(int numSillas) {
        this.juegoModell = new juegoModel(numSillas);
    }

    public void simularMusica() {
        juegoModell.simularMusica();
    }

    public boolean hayGanador() {
        return juegoModell.hayGanador();
    }

    public void mostrarEstado() {
        juegoModell.mostrarEstado();
    }
    public void ocuparSilla() {
        juegoModell.ocuparSilla();
    }
}
