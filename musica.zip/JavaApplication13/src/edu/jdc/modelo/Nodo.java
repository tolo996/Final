package edu.jdc.modelo;

public class Nodo {

    boolean ocupada;
    Nodo siguiente;

    public Nodo() {
        this.ocupada = false;
        this.siguiente = null;
    }
}
