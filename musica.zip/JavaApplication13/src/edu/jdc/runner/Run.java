
package edu.jdc.runner;

import edu.jdc.control.Control;
import edu.jdc.view.View;


public class Run {
    public static void main(String[] args) {
        Control juegoController = new Control(5);
        View juegoView = new View();

        while (!juegoController.hayGanador()) {
            juegoView.mostrarMensaje("¡La música está sonando!");
            juegoController.simularMusica();
            juegoView.mostrarMensaje("¡La música se detuvo!");
            juegoController.ocuparSilla();
            juegoController.mostrarEstado();
        }

        juegoView.mostrarMensaje("¡Tenemos un ganador!");
    }
}
