
package edu.jdc.view;


public class View {
   public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    
}
}
